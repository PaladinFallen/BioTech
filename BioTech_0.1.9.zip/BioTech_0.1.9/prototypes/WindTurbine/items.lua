data:extend({
	{
		type = "item",
		name = "biotech-wind-turbine",
		icon = "__BioTech__/graphics/icons/wind_turbine_icon.png",
		flags = {"goes-to-quickbar"},
		subgroup = "biotech-equipment",	
    order = "b[wind]",
		place_result = "biotech-wind-turbine",
		stack_size = 20,
	},

})