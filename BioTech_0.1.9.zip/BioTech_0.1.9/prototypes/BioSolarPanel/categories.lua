data:extend(
{

	{
		type = "recipe-category",
		name = "biotech-mod-biosolarpanel"
	},
	
}
)