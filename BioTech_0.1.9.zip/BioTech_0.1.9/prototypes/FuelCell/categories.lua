data:extend({
  {
    type = "recipe-category",
    name = "crafting-biotech-fuel-cell"
  },
})
