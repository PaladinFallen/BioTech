data:extend({
  {
    type = "item",
    name = "biotech-fuel-cell",
    icon = "__BioTech__/graphics/icons/fuel-cell-machine.png",
    flags = { "goes-to-quickbar" },
    subgroup = "biotech-equipment",
    order = "e[other]",
    place_result = "biotech-fuel-cell",
    stack_size = 10
  },

})
