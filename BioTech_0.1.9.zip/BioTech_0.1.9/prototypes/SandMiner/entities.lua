data:extend(
{

  {
    type = "assembling-machine",
    name = "electric-sand-mining-drill",
    icon = "__base__/graphics/icons/electric-mining-drill.png",
    flags = {"placeable-neutral", "player-creation"},
    minable = {mining_time = 1, result = "electric-sand-mining-drill"},
    max_health = 300,
    resource_categories = {"basic-solid"},
    corpse = "big-remnants",
    collision_box = {{ -1.4, -1.4}, {1.4, 1.4}},
    selection_box = {{ -1.5, -1.5}, {1.5, 1.5}},
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    crafting_categories = {"biotech-mod-sandminer"},
    crafting_speed = 0.70,
    ingredient_count = 1,	
    working_sound =
    {
      sound =
      {
        filename = "__base__/sound/electric-mining-drill.ogg",
        volume = 0.75
      },
      apparent_volume = 1.5,
    },
    animation =
    {
      --filename = "__base__/graphics/entity/electric-mining-drill/north.png",
      filename = "__BioTech__/graphics/entities/mining-drills/north4.png",
      priority = "extra-high",
      width = 110,
      height = 114,
      frame_count = 64,
      line_length = 8,
      animation_speed = 0.4,
      shift = {0.2, -0.2},
      run_mode = "forward-then-backward",
    },
    energy_source =
    {
      type = "electric",
      -- will produce this much * energy pollution units per tick
      emissions = 0.15 / 1.5,
      usage_priority = "secondary-input"
    },
    energy_usage = "90kW",
    mining_power = 3,
    resource_searching_radius = 2.49,
    vector_to_place_result = {0, -1.85},
    module_specification =
    {
      module_slots = 3
    },
    radius_visualisation_picture =
    {
      filename = "__base__/graphics/entity/electric-mining-drill/electric-mining-drill-radius-visualization.png",
      width = 12,
      height = 12
    },
    fast_replaceable_group = "mining-drill"
  },
  
  {
    type = "assembling-machine",
    name = "burner-sand-mining-drill",
    icon = "__base__/graphics/icons/burner-mining-drill.png",
    flags = {"placeable-neutral", "player-creation"},
    resource_categories = {"basic-solid"},
    minable = {mining_time = 1, result = "burner-sand-mining-drill"},
    max_health = 100,
    corpse = "medium-remnants",
    collision_box = {{ -0.9, -0.9}, {0.9, 0.9}},
    selection_box = {{ -1, -1}, {1, 1}},
    mining_speed = 0.35,
    crafting_categories = {"biotech-mod-sandminer"},
    crafting_speed = 0.4,
    ingredient_count = 1,	
    working_sound =
    {
      sound =
      {
        filename = "__base__/sound/burner-mining-drill.ogg",
        volume = 0.8
      },
    },
    energy_source =
    {
      type = "burner",
      effectivity = 1,
      fuel_inventory_size = 1,
      emissions = 0.1 / 3,
      smoke =
      {
        {
          name = "smoke",
          deviation = {0.1, 0.1},
          frequency = 3
        }
      }
    },
    energy_usage = "300kW",
    mining_power = 2.5,
    animation =
    {
		priority = "extra-high",
		width = 110,
		height = 76,
		line_length = 4,
		shift = {0.6875, -0.09375},
		filename = "__base__/graphics/entity/burner-mining-drill/north.png",
		frame_count = 32,
		animation_speed = 0.5,
		run_mode = "forward-then-backward",
    },
    resource_searching_radius = 0.99,
    vector_to_place_result = {-0.5, -1.3},
    fast_replaceable_group = "mining-drill"
  }
}
)
