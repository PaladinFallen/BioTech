data:extend(
{

	{
		type = "recipe-category",
		name = "biotech-mod-sandminer"
	},

    {
    type = "item-subgroup",
    name = "biotech-mod-sandminer",
    group = "production",
    order = "d1",
  },

}
)