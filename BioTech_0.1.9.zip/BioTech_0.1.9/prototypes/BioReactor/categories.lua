data:extend(
{

	{
		type = "recipe-category",
		name = "biotech-mod-bioreactor"
	},

	{
		type = "recipe-category",
		name = "biotech-mod-dummy"
	},

}
)