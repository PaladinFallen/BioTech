--- Wood Floors
data.raw.item["wood"].place_as_tile =
{
  result = "biotech-wood-floor",
  condition_size = 4,
  condition = { "water-tile" }
}